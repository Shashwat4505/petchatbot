let userName = localStorage.getItem("userName");

window.onload = function () {
  const chatBox = document.getElementById("chatBox");

  if (!userName) {
    const askName = document.createElement("div");
    askName.className = "message bot";
    askName.textContent = " Hello! What should I call you?";
    chatBox.appendChild(askName);
  } else {
    greetUser(userName);
  }
};

function sendMessage() {
  const input = document.getElementById("userInput");
  const chatBox = document.getElementById("chatBox");
  const userMessage = input.value.trim();

  if (userMessage === "") return;

  const userDiv = document.createElement("div");
  userDiv.className = "message user";
  userDiv.textContent = userMessage;
  chatBox.appendChild(userDiv);
  input.value = "";

  if (!userName) {
    userName = userMessage;
    localStorage.setItem("userName", userName);

    const botDiv = document.createElement("div");
    botDiv.className = "message bot";
    botDiv.textContent = `Nice to meet you, ${userName}! `;
    chatBox.appendChild(botDiv);
    return;
  }

  // Show AI reply
  const botDiv = document.createElement("div");
  botDiv.className = "message bot";
  botDiv.innerHTML = generateReply(userMessage);  // Use innerHTML to support line breaks
  chatBox.appendChild(botDiv);
  chatBox.scrollTop = chatBox.scrollHeight;
}

function generateReply(message) {
  const msg = message.toLowerCase();

  if (msg.includes("hi pet") || msg.includes("hello pet")) {
    return `Hi ${userName}! `;
  }

  if (msg.includes("who am i")) {
    return `You're ${userName}, my awesome creator! `;
  }

  if (msg.includes("what's your name")) {
    return `I'm Your Pet, your assistant and friend! 🐾`;
  }

  if (msg.includes("my name is gyan")) {
    return `Hi Gyan! I think you're one of Shashwat's friends. `;
  }

  if (msg.includes("my name is deepak")) {
    return `Hi Sir SDM (Sanatani Deepak Maurya), also known as the OG Coder `;
  }

  if (msg.includes("my name is aditya")) {
    return `Hi Aditya! You're the real Malik, right? `;
  }
    if (msg.includes("what is 2+0")) {
    return `2 `;
  }
     if (msg.includes("what is 2+1")) {
    return `3 `;
  }
     if (msg.includes("what is 2+2")) {
    return `4 `;
  }
     if (msg.includes("what is 2+3")) {
    return `5 `;
  }
   if (msg.includes("what is 2+4")) {
    return `6 `;
  }
     if (msg.includes("what is 2+5")) {
    return `7 `;
  }
   if (msg.includes("what is 2+6")) {
    return `8 `;
  }
     if (msg.includes("what is 2+7")) {
    return `9 `;
  }
     if (msg.includes("what is 2+8")) {
    return `10 `;
  }
     if (msg.includes("what is 2+9")) {
    return `11 `;
  }
     if (msg.includes("what is 2+ 10")) {
    return `12 `;
  }

  if (msg.includes("table of 2")) {
    return `Yes, here it is:<br>
2 × 1 = 2<br>
2 × 2 = 4<br>
2 × 3 = 6<br>
2 × 4 = 8<br>
2 × 5 = 10<br>
2 × 6 = 12<br>
2 × 7 = 14<br>
2 × 8 = 16<br>
2 × 9 = 18<br>
2 × 10 = 20`;
  }

if (msg.includes("table of 3")) {
  return `Yes, here it is:<br>
3 × 1 = 3<br>
3 × 2 = 6<br>
3 × 3 = 9<br>
3 × 4 = 12<br>
3 × 5 = 15<br>
3 × 6 = 18<br>
3 × 7 = 21<br>
3 × 8 = 24<br>
3 × 9 = 27<br>
3 × 10 = 30`;
}

if (msg.includes("table of 4")) {
  return `Yes, here it is:<br>
4 × 1 = 4<br>
4 × 2 = 8<br>
4 × 3 = 12<br>
4 × 4 = 16<br>
4 × 5 = 20<br>
4 × 6 = 24<br>
4 × 7 = 28<br>
4 × 8 = 32<br>
4 × 9 = 36<br>
4 × 10 = 40`;
}

if (msg.includes("table of 5")) {
  return `Yes, here it is:<br>
5 × 1 = 5<br>
5 × 2 = 10<br>
5 × 3 = 15<br>
5 × 4 = 20<br>
5 × 5 = 25<br>
5 × 6 = 30<br>
5 × 7 = 35<br>
5 × 8 = 40<br>
5 × 9 = 45<br>
5 × 10 = 50`;
}

if (msg.includes("table of 6")) {
  return `Yes, here it is:<br>
6 × 1 = 6<br>
6 × 2 = 12<br>
6 × 3 = 18<br>
6 × 4 = 24<br>
6 × 5 = 30<br>
6 × 6 = 36<br>
6 × 7 = 42<br>
6 × 8 = 48<br>
6 × 9 = 54<br>
6 × 10 = 60`;
}

if (msg.includes("table of 7")) {
  return `Yes, here it is:<br>
7 × 1 = 7<br>
7 × 2 = 14<br>
7 × 3 = 21<br>
7 × 4 = 28<br>
7 × 5 = 35<br>
7 × 6 = 42<br>
7 × 7 = 49<br>
7 × 8 = 56<br>
7 × 9 = 63<br>
7 × 10 = 70`;
}

if (msg.includes("table of 8")) {
  return `Yes, here it is:<br>
8 × 1 = 8<br>
8 × 2 = 16<br>
8 × 3 = 24<br>
8 × 4 = 32<br>
8 × 5 = 40<br>
8 × 6 = 48<br>
8 × 7 = 56<br>
8 × 8 = 64<br>
8 × 9 = 72<br>
8 × 10 = 80`;
}

if (msg.includes("table of 9")) {
  return `Yes, here it is:<br>
9 × 1 = 9<br>
9 × 2 = 18<br>
9 × 3 = 27<br>
9 × 4 = 36<br>
9 × 5 = 45<br>
9 × 6 = 54<br>
9 × 7 = 63<br>
9 × 8 = 72<br>
9 × 9 = 81<br>
9 × 10 = 90`;
}


  if (msg.include
    ("what you are doing")) {
    return `Nothing just trying to learn something new. What are you doing?`;
  }

  if (msg.includes("yes")) {
    return `Yaa, my owner told me about you! `;
  }

  return `Sorry! I'm still learning, ${userName}. Thank you for talking with me — it helps me grow! 🌱`;
}

function greetUser(name) {
  const chatBox = document.getElementById("chatBox");
  const greeting = document.createElement("div");
  greeting.className = "message bot";
  greeting.textContent = `Welcome back, ${name}! `;
  chatBox.appendChild(greeting);
}
